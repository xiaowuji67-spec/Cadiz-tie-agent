# Cádiz TIE Appointment Page Monitor (Free MVP)

This is a conservative, once-daily monitor for the official Spanish ICP Plus appointment portal.

## What it does
- Opens the official ICP Plus entry page once per day using Playwright.
- Reports whether the page loaded, errored, timed out, or displayed a human-verification challenge.
- Sends one status email per run using Gmail SMTP.
- Can also be run manually from GitHub Actions.

## What it does NOT do
- It does not prove that a Cádiz TIE fingerprint appointment slot is available.
- It does not select a province or procedure, book, reserve, or submit a form.
- It does not solve CAPTCHAs, bypass anti-bot controls, rotate IPs, or evade access restrictions.
- It does not store NIE, passport details, passwords, or other identity data.

This first version is intentionally limited because the ICP Plus flow and its access controls may change. A successful page load is not the same as confirmed appointment availability.

## Free deployment
Use a **public GitHub repository** for the simplest free scheduled GitHub Actions setup. Public repositories have free standard GitHub-hosted runner usage, but GitHub may delay scheduled workflows and does not guarantee exact execution time. If you use a private repository, check the current Actions minutes allowance for your account.

1. Create a GitHub account at https://github.com/signup
2. Create a new repository named `cadiz-tie-agent`. For the easiest free scheduled run, set it to **Public**. Do not upload personal documents or identity details.
3. Upload the files from this project, preserving the `.github/workflows/daily-monitor.yml` path.
4. In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.
5. Add these secrets:
   - `SMTP_HOST` = `smtp.gmail.com`
   - `SMTP_PORT` = `587`
   - `SMTP_USER` = your Gmail address
   - `SMTP_PASSWORD` = a Google App Password (not your normal Gmail password)
   - `ALERT_TO` = the address that should receive alerts
6. Enable 2-Step Verification on the Google account if needed, then create an App Password in Google Account security settings. If Google does not offer App Passwords for your account, do not try to work around that restriction; use another supported email provider or a mail service with a free tier.
7. Open **Actions** in the repository and enable workflows if prompted.
8. Select **Cádiz TIE daily page monitor → Run workflow** to test it.
9. Check the inbox. The scheduled run is once daily at 09:15 UTC. GitHub scheduled jobs can be delayed.

## Safety and privacy
- Never place passwords, App Passwords, NIE, passport numbers, or appointment documents in source files or chat.
- Store credentials only as GitHub Actions secrets.
- The repository contains no personal data by default. Keep it that way.
- If the portal shows CAPTCHA, identity verification, or an access warning, stop and continue manually on the official site.
- Review the official portal's terms and current instructions before using any automated monitoring.

## Official portal
https://sede.administracionespublicas.gob.es/icpplus/index.html
