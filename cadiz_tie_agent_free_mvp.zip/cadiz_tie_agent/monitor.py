import os
import re
import smtplib
import ssl
from email.message import EmailMessage
from datetime import datetime, timezone

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

URL = "https://sede.administracionespublicas.gob.es/icpplus/index.html"

def send_email(subject: str, body: str) -> None:
    host = os.environ["SMTP_HOST"]
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ["SMTP_USER"]
    password = os.environ["SMTP_PASSWORD"]
    recipient = os.environ["ALERT_TO"]

    msg = EmailMessage()
    msg["From"] = user
    msg["To"] = recipient
    msg["Subject"] = subject
    msg.set_content(body)

    context = ssl.create_default_context()
    with smtplib.SMTP(host, port, timeout=30) as server:
        server.starttls(context=context)
        server.login(user, password)
        server.send_message(msg)

def main():
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    status = "UNKNOWN"
    title = ""
    page_text = ""
    note = ""

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(
            locale="es-ES",
            user_agent="Mozilla/5.0 (compatible; AppointmentPageMonitor/1.0)"
        )
        try:
            response = page.goto(URL, wait_until="domcontentloaded", timeout=45000)
            page.wait_for_timeout(4000)
            title = page.title()
            page_text = re.sub(r"\s+", " ", page.locator("body").inner_text(timeout=10000)).strip()
            code = response.status if response else "no HTTP response"

            lower = page_text.lower()
            challenge_terms = ["captcha", "verifique que es usted", "actividad inusual",
                               "access denied", "cloudflare", "robot"]
            if any(term in lower for term in challenge_terms):
                status = "HUMAN_CHECK_REQUIRED"
                note = "页面出现验证码/访问验证；程序已停止，不会尝试绕过。"
            elif code != "no HTTP response" and int(code) >= 400:
                status = "SITE_ERROR"
                note = f"官方页面返回 HTTP {code}。"
            elif page_text:
                status = "PAGE_REACHED"
                note = ("已成功打开官方预约入口，但本版本不会自动选择省份、办理事项或提交预约。"
                        "请人工进入页面检查 Cádiz 的 TIE 指纹预约时段。")
            else:
                status = "PAGE_EMPTY"
                note = "页面已打开，但没有读取到正文；可能是网页结构变化或加载失败。"
        except PlaywrightTimeoutError:
            status = "TIMEOUT"
            note = "官方页面加载超时。"
        except Exception as exc:
            status = "ERROR"
            note = f"检查时发生错误：{type(exc).__name__}: {exc}"
        finally:
            browser.close()

    # Send a single daily status email. This is a page monitor, not a slot-availability guarantee.
    body = (
        f"Cádiz TIE 官方预约页面监测\n\n"
        f"检查时间：{now}\n"
        f"状态：{status}\n"
        f"页面标题：{title or '(无)'}\n"
        f"说明：{note}\n\n"
        f"官方入口：{URL}\n\n"
        "重要：此免费版本只做低频页面可达性/异常提醒，不会声称已确认有可预约时段。"
        "如页面出现验证码、登录或身份验证，必须由你本人处理；程序不会绕过保护。"
    )
    send_email(f"[Cádiz TIE Agent] {status}", body)
    print(body)

if __name__ == "__main__":
    main()
